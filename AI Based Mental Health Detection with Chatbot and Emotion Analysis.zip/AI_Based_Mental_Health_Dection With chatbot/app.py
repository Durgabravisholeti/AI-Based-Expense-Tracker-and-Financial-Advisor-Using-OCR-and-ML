from flask import Flask, render_template, request, redirect, session
import sqlite3

app = Flask(__name__)
app.secret_key = "secret123"


# ─── DB HELPERS ───────────────────────────────────────────────

def init_users_db():
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            email TEXT,
            password TEXT
        )
    """)
    conn.commit()
    conn.close()


def init_chat_db():
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            message TEXT,
            reply TEXT,
            emotion TEXT
        )
    """)
    conn.commit()
    conn.close()


# ─── EMOTION DETECTION ────────────────────────────────────────

def detect_emotion(text):
    text = text.lower()
    if any(w in text for w in ["happy", "great", "joy", "excited", "good", "wonderful", "amazing", "fantastic", "love", "blessed", "grateful", "cheerful", "delighted"]):
        return "Happy 😊"
    elif any(w in text for w in ["sad", "cry", "depressed", "unhappy", "down", "lonely", "hopeless", "miserable", "heartbroken", "grief", "sorrow", "empty", "lost"]):
        return "Sad 😔"
    elif any(w in text for w in ["stress", "anxious", "anxiety", "worried", "nervous", "panic", "overwhelmed", "pressure", "tense", "fear", "scared", "overthinking"]):
        return "Stressed 😣"
    elif any(w in text for w in ["angry", "mad", "furious", "rage", "hate", "frustrated", "irritated", "annoyed", "upset", "bitter"]):
        return "Angry 😠"
    elif any(w in text for w in ["tired", "exhausted", "sleepy", "fatigue", "drained", "burnout", "worn out", "no energy", "weak"]):
        return "Tired 😴"
    elif any(w in text for w in ["lonely", "alone", "isolated", "no one", "nobody", "abandoned", "left out", "invisible"]):
        return "Lonely 🥺"
    elif any(w in text for w in ["confused", "lost", "unsure", "don't know", "unclear", "uncertain", "stuck", "blank"]):
        return "Confused 😕"
    elif any(w in text for w in ["motivated", "inspired", "determined", "focused", "ready", "confident", "strong", "powerful"]):
        return "Motivated 💪"
    else:
        return "Neutral 😐"


def get_reply(text, emotion):
    text = text.lower()

    # ── Keyword-based smart replies ──────────────────────────
    if any(w in text for w in ["suicide", "kill myself", "end my life", "want to die", "don't want to live"]):
        return ("I'm really concerned about you right now 💙 Please reach out to a mental health "
                "professional or a crisis helpline immediately. You are not alone, and your life matters. "
                "Please talk to someone you trust right away. 🆘")

    if any(w in text for w in ["help", "need help", "please help", "support"]):
        return ("I'm here for you 💙 You've taken a brave step by reaching out. "
                "Tell me more about what you're going through — I'm listening and I care about how you feel.")

    if any(w in text for w in ["meditation", "meditate", "calm down", "relax", "breathe"]):
        return ("Meditation is a powerful tool 🧘 Try this: sit comfortably, close your eyes, "
                "and take 5 slow deep breaths. Inhale for 4 seconds, hold for 4, exhale for 6. "
                "Even 5 minutes of this daily can significantly reduce stress and anxiety.")

    if any(w in text for w in ["sleep", "can't sleep", "insomnia", "not sleeping", "sleepless"]):
        return ("Sleep is essential for mental health 😴 Try to maintain a consistent sleep schedule. "
                "Avoid screens 30 minutes before bed, keep your room cool and dark, and try deep breathing "
                "to calm your mind. A good night's rest can transform how you feel tomorrow 🌙")

    if any(w in text for w in ["panic attack", "panic", "heart racing", "can't breathe", "shaking"]):
        return ("It sounds like you may be having a panic attack. You are safe 💙 "
                "Try the 5-4-3-2-1 technique: name 5 things you can see, 4 you can touch, "
                "3 you can hear, 2 you can smell, 1 you can taste. This grounds you back to the present moment.")

    if any(w in text for w in ["overthink", "overthinking", "can't stop thinking", "mind won't stop"]):
        return ("Overthinking is exhausting 😔 When your mind spirals, try writing your thoughts down — "
                "it helps release them from your head. Then ask yourself: 'Is this thought helpful right now?' "
                "Focus on what you can control, and let go of what you can't 🌿")

    if any(w in text for w in ["motivation", "not motivated", "lazy", "procrastinate", "no energy to"]):
        return ("Lack of motivation is completely normal 💪 Start with the smallest possible step — "
                "even 5 minutes of action builds momentum. Break your goal into tiny pieces and celebrate "
                "each small win. Progress, no matter how small, is still progress 🌱")

    if any(w in text for w in ["lonely", "alone", "no friends", "no one cares", "isolated"]):
        return ("Feeling lonely is one of the hardest emotions 🥺 But please know — you are not invisible. "
                "I see you and I care. Try reaching out to one person today, even with a simple message. "
                "Connection starts with a single step, and you deserve to feel loved and supported 💙")

    if any(w in text for w in ["angry", "mad", "furious", "frustrated", "rage"]):
        return ("It's completely okay to feel angry — your feelings are valid 🌊 "
                "When anger rises, try stepping away for a moment. Take 3 deep breaths, "
                "go for a short walk, or write down what's bothering you. "
                "Anger is energy — channel it into something positive 💪")

    if any(w in text for w in ["happy", "great", "amazing", "wonderful", "excited", "good"]):
        return ("That's absolutely wonderful to hear! 🌟 Your positive energy is contagious. "
                "Hold onto this feeling and let it fuel your day. "
                "Happiness is a habit — keep nurturing it with gratitude and self-care 😊")

    if any(w in text for w in ["sad", "cry", "depressed", "hopeless", "heartbroken"]):
        return ("I'm truly sorry you're feeling this way 💙 Sadness is a natural human emotion, "
                "and it's okay to feel it. Allow yourself to grieve without judgment. "
                "Try talking to someone you trust, go for a gentle walk, or simply rest. "
                "This feeling will pass — you are stronger than you know 🌱")

    if any(w in text for w in ["stress", "stressed", "overwhelmed", "pressure", "too much"]):
        return ("I hear you — stress can feel suffocating 😣 Let's take it one step at a time. "
                "First, take a slow deep breath right now. Then write down everything on your mind "
                "and pick just ONE thing to focus on. You don't have to solve everything today. "
                "You've handled hard things before, and you can handle this too 💪")

    if any(w in text for w in ["tired", "exhausted", "drained", "burnout", "no energy"]):
        return ("Your body and mind are telling you something important — they need rest 💤 "
                "Burnout is real and it's serious. Give yourself permission to slow down today. "
                "Rest is not laziness; it's recovery. Take a nap, drink water, eat something nourishing, "
                "and be gentle with yourself 🌙")

    if any(w in text for w in ["thank", "thanks", "thank you", "grateful", "appreciate"]):
        return ("You're so welcome 💙 I'm always here whenever you need to talk. "
                "Remember, reaching out is a sign of strength, not weakness. "
                "Take care of yourself — you deserve all the good things 🌟")

    if any(w in text for w in ["hello", "hi", "hey", "good morning", "good evening", "good night"]):
        return ("Hello! 👋 I'm MindAI, your mental wellness companion. "
                "I'm here to listen, support, and guide you. "
                "How are you feeling today? Feel free to share anything on your mind 💙")

    # ── Emotion-based fallback replies ───────────────────────
    fallback = {
        "Happy 😊":     "Your happiness is truly uplifting! 🌟 Keep embracing the positive moments and share that energy with the world around you 😊",
        "Sad 😔":       "I'm here with you 💙 Sadness is temporary, even when it doesn't feel that way. Be kind to yourself today — you deserve care and compassion 🌱",
        "Stressed 😣":  "Breathe. You are doing better than you think 💪 Take things one moment at a time and remember — it's okay to ask for help 🧘",
        "Angry 😠":     "Your feelings are valid 🌊 Take a moment to breathe and step back. Anger often hides deeper pain — be gentle with yourself 🍃",
        "Tired 😴":     "Rest is productive too 💤 Your mind and body need recovery. Be patient with yourself and take the break you deserve 🌙",
        "Lonely 🥺":    "You are never truly alone 💙 I'm here, and there are people who care about you. One small connection today can change everything 🤝",
        "Confused 😕":  "It's okay not to have all the answers right now 🌿 Take a breath, slow down, and trust that clarity will come with time. You don't have to figure it all out today.",
        "Motivated 💪": "Yes! That energy is everything 🔥 Channel it into your goals today. You have what it takes — believe in yourself and keep moving forward 🚀",
        "Neutral 😐":   "I'm here and I'm listening 💬 Sometimes we don't have the words for how we feel, and that's okay. Take your time — I'm not going anywhere 🤝",
    }
    return fallback.get(emotion, "I'm here for you 💙 Whatever you're going through, you don't have to face it alone. I'm listening 🌿")


# ─── ROUTES ───────────────────────────────────────────────────

@app.route("/")
def index():
    return redirect("/landing")


@app.route("/landing")
def landing():
    return render_template("landing.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    message = ""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        conn = sqlite3.connect("users.db")
        cur = conn.cursor()
        cur.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = cur.fetchone()
        conn.close()

        if user:
            session["user"] = username
            return redirect("/home")
        else:
            message = "Invalid username or password"

    return render_template("login.html", message=message)


@app.route("/register", methods=["GET", "POST"])
def register():
    message = ""
    if request.method == "POST":
        username = request.form.get("username")
        email = request.form.get("email")
        password = request.form.get("password")
        confirm = request.form.get("confirm_password")

        if password != confirm:
            message = "Passwords do not match"
        else:
            try:
                conn = sqlite3.connect("users.db")
                cur = conn.cursor()
                cur.execute("INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                            (username, email, password))
                conn.commit()
                conn.close()
                message = "Account created! Please login."
            except sqlite3.IntegrityError:
                message = "Username already exists"

    return render_template("register.html", message=message)


@app.route("/logout")
def logout():
    session.clear()
    return redirect("/landing")


@app.route("/home")
def home():
    if "user" not in session:
        return redirect("/login")
    return render_template("home.html")


@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect("/login")

    init_chat_db()
    conn = sqlite3.connect("users.db")
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM chats WHERE username=?", (session["user"],))
    chat_count = cur.fetchone()[0]
    conn.close()

    progress = min(chat_count * 10, 100)
    return render_template("dashboard.html", chat_count=chat_count, progress=progress)


@app.route("/chat", methods=["GET", "POST"])
def chat():
    if "user" not in session:
        return redirect("/login")

    init_chat_db()
    user_msg = ""
    reply = ""
    emotion = ""

    if request.method == "POST":
        user_msg = request.form.get("message", "")
        emotion = detect_emotion(user_msg)
        reply = get_reply(user_msg, emotion)

        conn = sqlite3.connect("users.db")
        cur = conn.cursor()
        cur.execute("INSERT INTO chats (username, message, reply, emotion) VALUES (?, ?, ?, ?)",
                    (session["user"], user_msg, reply, emotion))
        conn.commit()
        conn.close()

    return render_template("chat.html", user_msg=user_msg, reply=reply, emotion=emotion)


@app.route("/about")
def about():
    return render_template("about.html")


# ─── CONTACT ──────────────────────────────────────────────────

@app.route("/contact", methods=["GET", "POST"])
def contact():
    message = ""
    if request.method == "POST":
        name = request.form.get("name")
        email = request.form.get("email")
        msg = request.form.get("message")

        conn = sqlite3.connect("contact.db")
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                name TEXT, email TEXT, message TEXT
            )
        """)
        cur.execute("INSERT INTO messages VALUES (?, ?, ?)", (name, email, msg))
        conn.commit()
        conn.close()

        message = "Message sent successfully!"

    return render_template("contact.html", message=message)


# ─── ADMIN ────────────────────────────────────────────────────

@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():
    error = ""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if username == "admin" and password == "1234":
            session["admin"] = True
            return redirect("/admin")
        else:
            error = "Invalid login"

    return render_template("admin_login.html", error=error)


@app.route("/admin")
def admin():
    if "admin" not in session:
        return redirect("/admin_login")

    conn = sqlite3.connect("contact.db")
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS messages (
            name TEXT, email TEXT, message TEXT
        )
    """)
    cur.execute("SELECT * FROM messages")
    data = cur.fetchall()
    conn.close()

    return render_template("admin.html", data=data)


# ─── INIT & RUN ───────────────────────────────────────────────

if __name__ == "__main__":
    init_users_db()
    init_chat_db()
    app.run(debug=True)
